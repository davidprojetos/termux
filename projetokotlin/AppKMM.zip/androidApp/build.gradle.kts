plugins {
    id("com.android.application")
    kotlin("android")
}

android {
    namespace = "com.appkmm.android"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.appkmm.android"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }
}

dependencies {
    implementation(project(":shared"))
}
