package com.appkmm.shared

class Greeting {
    fun greet(): String {
        return "Olá do Kotlin Multiplatform!"
    }
}
