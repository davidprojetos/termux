rootProject.name = "AppKMM"
include(":shared")
include(":androidApp")
